//
//  LPTheos.xm
//  LPTheos
//
//  Created by Pigi Galdi on 14.10.2014.
//  Copyright (c) 2014 Pigi Galdi. All rights reserved.
//
// 	Apple.
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//	Thanks Saurik.
#include <substrate.h>
// 	Import LPView and LPViewController.
#import "LPView.h"
#import "LPViewController.h"
// 	Import liblockpages header.
#import <liblockpages/LPPageController.h>
